<?php

namespace App\Dal;

use App\Model\Usuario;
use PDO;

abstract class UsuarioDao extends Conn
{
    public static function cadastrar(Usuario $usuario): int
    {
        $sql  = "INSERT INTO usuarios (nome, email, senha) VALUES (:nome, :email, :senha)";
        $stmt = self::getConn()->prepare($sql);
        $stmt->execute([
            ':nome'  => $usuario->getNome(),
            ':email' => $usuario->getEmail(),
            ':senha' => $usuario->getSenha(),
        ]);
        return (int) self::getConn()->lastInsertId();
    }

    public static function listar(): array
    {
        $stmt = self::getConn()->query(
            "SELECT id, nome, email, senha, token_lembrar, criado_em FROM usuarios ORDER BY nome ASC"
        );
        $usuarios = [];
        foreach ($stmt->fetchAll() as $row) {
            $usuarios[] = self::arrayParaUsuario($row);
        }
        return $usuarios;
    }

    public static function buscarPorId(int $id): ?Usuario
    {
        $stmt = self::getConn()->prepare(
            "SELECT id, nome, email, senha, token_lembrar, criado_em FROM usuarios WHERE id = :id LIMIT 1"
        );
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ? self::arrayParaUsuario($row) : null;
    }

    public static function buscarPorEmail(string $email): ?Usuario
    {
        $stmt = self::getConn()->prepare(
            "SELECT id, nome, email, senha, token_lembrar, criado_em FROM usuarios WHERE email = :email LIMIT 1"
        );
        $stmt->execute([':email' => $email]);
        $row = $stmt->fetch();
        return $row ? self::arrayParaUsuario($row) : null;
    }

    public static function buscarPorToken(string $token): ?Usuario
    {
        $stmt = self::getConn()->prepare(
            "SELECT id, nome, email, senha, token_lembrar, criado_em FROM usuarios WHERE token_lembrar = :token LIMIT 1"
        );
        $stmt->execute([':token' => $token]);
        $row = $stmt->fetch();
        return $row ? self::arrayParaUsuario($row) : null;
    }

    public static function atualizarToken(int $id, ?string $token): void
    {
        $stmt = self::getConn()->prepare(
            "UPDATE usuarios SET token_lembrar = :token WHERE id = :id"
        );
        $stmt->execute([':token' => $token, ':id' => $id]);
    }

    public static function emailExiste(string $email): bool
    {
        $stmt = self::getConn()->prepare(
            "SELECT COUNT(*) FROM usuarios WHERE email = :email"
        );
        $stmt->execute([':email' => $email]);
        return (int) $stmt->fetchColumn() > 0;
    }

    private static function arrayParaUsuario(array $row): Usuario
    {
        return Usuario::criar(
            (int) $row['id'],
            $row['nome'],
            $row['email'],
            $row['senha'],
            $row['token_lembrar'] ?? null,
            $row['criado_em']
        );
    }
}
