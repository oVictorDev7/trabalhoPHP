<?php

namespace App\Dal;

use App\Model\Tarefa;
use PDO;

abstract class TarefaDao extends Conn
{
    public static function cadastrar(Tarefa $tarefa): int
    {
        $sql = "INSERT INTO tarefas (titulo, descricao, data_limite, status, criador_id, responsavel_id)
                VALUES (:titulo, :descricao, :data_limite, :status, :criador_id, :responsavel_id)";

        $stmt = self::getConn()->prepare($sql);
        $stmt->execute([
            ':titulo'         => $tarefa->getTitulo(),
            ':descricao'      => $tarefa->getDescricao(),
            ':data_limite'    => $tarefa->getDataLimite(),
            ':status'         => $tarefa->getStatus(),
            ':criador_id'     => $tarefa->getCriadorId(),
            ':responsavel_id' => $tarefa->getResponsavelId(),
        ]);

        $id = (int) self::getConn()->lastInsertId();

        foreach ($tarefa->getHistorico() as $h) {
            self::inserirHistorico($id, (int) $h['usuario_id'], $h['acao']);
        }

        foreach ($tarefa->getComentarios() as $c) {
            self::inserirComentario($id, (int) $c['usuario_id'], $c['texto']);
        }

        return $id;
    }

    public static function atualizar(Tarefa $tarefa): void
    {
        $sql = "UPDATE tarefas
                SET titulo = :titulo, descricao = :descricao,
                    data_limite = :data_limite, status = :status,
                    responsavel_id = :responsavel_id
                WHERE id = :id";

        $stmt = self::getConn()->prepare($sql);
        $stmt->execute([
            ':titulo'         => $tarefa->getTitulo(),
            ':descricao'      => $tarefa->getDescricao(),
            ':data_limite'    => $tarefa->getDataLimite(),
            ':status'         => $tarefa->getStatus(),
            ':responsavel_id' => $tarefa->getResponsavelId(),
            ':id'             => $tarefa->getId(),
        ]);
    }

    public static function buscarPorId(int $id): ?Tarefa
    {
        $stmt = self::getConn()->prepare(
            "SELECT id, titulo, descricao, data_limite, status,
                    criador_id, responsavel_id, criado_em, atualizado_em
             FROM tarefas WHERE id = :id LIMIT 1"
        );
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();

        if (!$row) {
            return null;
        }

        $comentarios = self::buscarComentarios($id);
        $historico   = self::buscarHistorico($id);

        return self::arrayParaTarefa($row, $comentarios, $historico);
    }

    public static function listar(array $filtros = []): array
    {
        $sql    = "SELECT id, titulo, descricao, data_limite, status,
                          criador_id, responsavel_id, criado_em, atualizado_em
                   FROM tarefas WHERE 1=1";
        $params = [];

        if (!empty($filtros['responsavel_id'])) {
            $sql .= " AND responsavel_id = :responsavel_id";
            $params[':responsavel_id'] = (int) $filtros['responsavel_id'];
        }

        if (!empty($filtros['status'])) {
            $sql .= " AND status = :status";
            $params[':status'] = $filtros['status'];
        }

        if (!empty($filtros['data_limite'])) {
            $sql .= " AND data_limite = :data_limite";
            $params[':data_limite'] = $filtros['data_limite'];
        }

        $sql .= " ORDER BY data_limite ASC, criado_em DESC";

        $stmt = self::getConn()->prepare($sql);
        $stmt->execute($params);

        $tarefas = [];
        foreach ($stmt->fetchAll() as $row) {
            
            $comentarios = self::buscarComentarios((int) $row['id']);
            $historico   = self::buscarHistorico((int) $row['id']);
            $tarefas[]   = self::arrayParaTarefa($row, $comentarios, $historico);
        }

        return $tarefas;
    }


    public static function deletar(int $id): void
    {
        $stmt = self::getConn()->prepare("DELETE FROM tarefas WHERE id = :id");
        $stmt->execute([':id' => $id]);
    }

    public static function inserirComentario(int $tarefaId, int $usuarioId, string $texto): int
    {
        $stmt = self::getConn()->prepare(
            "INSERT INTO comentarios (tarefa_id, usuario_id, texto) VALUES (:tarefa_id, :usuario_id, :texto)"
        );
        $stmt->execute([
            ':tarefa_id'  => $tarefaId,
            ':usuario_id' => $usuarioId,
            ':texto'      => $texto,
        ]);
        return (int) self::getConn()->lastInsertId();
    }

    public static function inserirHistorico(int $tarefaId, int $usuarioId, string $acao): void
    {
        $stmt = self::getConn()->prepare(
            "INSERT INTO historico (tarefa_id, usuario_id, acao) VALUES (:tarefa_id, :usuario_id, :acao)"
        );
        $stmt->execute([
            ':tarefa_id'  => $tarefaId,
            ':usuario_id' => $usuarioId,
            ':acao'       => $acao,
        ]);
    }

    private static function buscarComentarios(int $tarefaId): array
    {
        $stmt = self::getConn()->prepare(
            "SELECT id, usuario_id, texto, criado_em FROM comentarios
             WHERE tarefa_id = :tarefa_id ORDER BY criado_em ASC"
        );
        $stmt->execute([':tarefa_id' => $tarefaId]);
        return $stmt->fetchAll();
    }

    private static function buscarHistorico(int $tarefaId): array
    {
        $stmt = self::getConn()->prepare(
            "SELECT id, usuario_id, acao, criado_em FROM historico
             WHERE tarefa_id = :tarefa_id ORDER BY criado_em DESC"
        );
        $stmt->execute([':tarefa_id' => $tarefaId]);
        return $stmt->fetchAll();
    }

    private static function arrayParaTarefa(array $row, array $comentarios, array $historico): Tarefa
    {
        return Tarefa::criar(
            (int) $row['id'],
            $row['titulo'],
            $row['descricao'] ?? '',
            $row['data_limite'],
            $row['status'],
            (int) $row['criador_id'],
            (int) $row['responsavel_id'],
            $row['criado_em'],
            $row['atualizado_em'],
            $comentarios,
            $historico
        );
    }
}
