<?php

namespace App\Dal;

use PDO;
use PDOException;
use Exception;

abstract class Conn
{
    private static ?PDO $conn = null;

    private static string $host   = "localhost";
    private static string $dbname = "taskflow";
    private static string $user   = "root";
    private static string $password = "";

    public static function getConn(): PDO
    {
        if (self::$conn === null) {
            try {
                self::$conn = new PDO(
                    "mysql:host=" . self::$host . ";dbname=" . self::$dbname . ";charset=utf8mb4",
                    self::$user,
                    self::$password
                );
                self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                throw new Exception("Erro ao conectar ao banco: " . $e->getMessage());
            }
        }
        return self::$conn;
    }
}
