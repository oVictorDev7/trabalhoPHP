<?php

namespace App\Util;

class Functions
{
    public static function prepararTexto(string $texto): string
    {
        return trim(htmlspecialchars($texto));
    }

    public static function validarCsrf(string $tokenRecebido): bool
    {
        return isset($_SESSION['csrf_token'])
            && hash_equals($_SESSION['csrf_token'], $tokenRecebido);
    }

    public static function labelStatus(string $status): string
    {
        return match($status) {
            'pendente'     => 'Pendente',
            'em_andamento' => 'Em Andamento',
            'concluida'    => 'Concluída',
            default        => 'Desconhecido'
        };
    }

    public static function classeStatus(string $status): string
    {
        return match($status) {
            'pendente'     => 'badge-pendente',
            'em_andamento' => 'badge-andamento',
            'concluida'    => 'badge-concluida',
            default        => ''
        };
    }

    public static function formatarData(string $data): string
    {
        if (empty($data)) {
            return '-';
        }
        $dt = \DateTime::createFromFormat('Y-m-d', $data);
        return $dt ? $dt->format('d/m/Y') : $data;
    }


    public static function iconeStatus(string $status): string
    {
        return match($status) {
            'pendente'     => '&#9200;',  // ⏰
            'em_andamento' => '&#9654;',  // ▶
            'concluida'    => '&#10003;', // ✓
            default        => '&#8226;'   // •
        };
    }
}
