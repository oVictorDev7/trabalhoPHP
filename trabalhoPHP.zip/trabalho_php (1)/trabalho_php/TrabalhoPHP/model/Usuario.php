<?php

namespace App\Model;

class Usuario
{
    private ?int    $id;
    private string  $nome;
    private string  $email;
    private string  $senha;
    private ?string $tokenLembrar;
    private string  $criadoEm;

    private function __construct(
        ?int $id,
        string $nome,
        string $email,
        string $senha,
        ?string $tokenLembrar,
        string $criadoEm
    ) {
        $this->id           = $id;
        $this->nome         = $nome;
        $this->email        = $email;
        $this->senha        = $senha;
        $this->tokenLembrar = $tokenLembrar;
        $this->criadoEm     = $criadoEm;
    }

    public static function criar(
        ?int $id,
        string $nome,
        string $email,
        string $senha,
        ?string $tokenLembrar = null,
        ?string $criadoEm = null
    ): static {
        if (trim($nome) === '') {
            throw new \InvalidArgumentException('O nome é obrigatório');
        }
        if (trim($email) === '') {
            throw new \InvalidArgumentException('O e-mail é obrigatório');
        }
        return new static($id, $nome, $email, $senha, $tokenLembrar, $criadoEm ?? date('Y-m-d H:i:s'));
    }

    public function getId(): ?int            { return $this->id; }
    public function getNome(): string        { return $this->nome; }
    public function getEmail(): string       { return $this->email; }
    public function getSenha(): string       { return $this->senha; }
    public function getTokenLembrar(): ?string { return $this->tokenLembrar; }
    public function getCriadoEm(): string    { return $this->criadoEm; }

    public function setNome(string $nome): void
    {
        if (trim($nome) === '') {
            throw new \InvalidArgumentException('O nome é obrigatório');
        }
        $this->nome = $nome;
    }

    public function setTokenLembrar(?string $token): void
    {
        $this->tokenLembrar = $token;
    }
}
