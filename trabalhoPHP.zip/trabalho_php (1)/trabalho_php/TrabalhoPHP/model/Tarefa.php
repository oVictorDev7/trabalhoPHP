<?php

namespace App\Model;

class Tarefa
{
    private ?int   $id;
    private string $titulo;
    private string $descricao;
    private string $dataLimite;
    private string $status;
    private int    $criadorId;
    private int    $responsavelId;
    private string $criadoEm;
    private string $atualizadoEm;
    private array  $comentarios;
    private array  $historico;

    private function __construct(
        ?int $id,
        string $titulo,
        string $descricao,
        string $dataLimite,
        string $status,
        int $criadorId,
        int $responsavelId,
        string $criadoEm,
        string $atualizadoEm,
        array $comentarios,
        array $historico
    ) {
        $this->id            = $id;
        $this->titulo        = $titulo;
        $this->descricao     = $descricao;
        $this->dataLimite    = $dataLimite;
        $this->status        = $status;
        $this->criadorId     = $criadorId;
        $this->responsavelId = $responsavelId;
        $this->criadoEm      = $criadoEm;
        $this->atualizadoEm  = $atualizadoEm;
        $this->comentarios   = $comentarios;
        $this->historico     = $historico;
    }

    public static function criar(
        ?int $id,
        string $titulo,
        string $descricao,
        string $dataLimite,
        string $status,
        int $criadorId,
        int $responsavelId,
        ?string $criadoEm     = null,
        ?string $atualizadoEm = null,
        array $comentarios    = [],
        array $historico      = []
    ): static {
        if (trim($titulo) === '') {
            throw new \InvalidArgumentException('O título é obrigatório');
        }

        $statusValidos = ['pendente', 'em_andamento', 'concluida'];
        if (!in_array($status, $statusValidos)) {
            throw new \InvalidArgumentException('Status inválido');
        }

        $agora = date('Y-m-d H:i:s');
        return new static(
            $id, $titulo, $descricao, $dataLimite, $status,
            $criadorId, $responsavelId,
            $criadoEm ?? $agora,
            $atualizadoEm ?? $agora,
            $comentarios, $historico
        );
    }

    public function getId(): ?int             { return $this->id; }
    public function getTitulo(): string       { return $this->titulo; }
    public function getDescricao(): string    { return $this->descricao; }
    public function getDataLimite(): string   { return $this->dataLimite; }
    public function getStatus(): string       { return $this->status; }
    public function getCriadorId(): int       { return $this->criadorId; }
    public function getResponsavelId(): int   { return $this->responsavelId; }
    public function getCriadoEm(): string     { return $this->criadoEm; }
    public function getAtualizadoEm(): string { return $this->atualizadoEm; }
    public function getComentarios(): array   { return $this->comentarios; }
    public function getHistorico(): array     { return $this->historico; }


    public function setTitulo(string $titulo): void
    {
        if (trim($titulo) === '') {
            throw new \InvalidArgumentException('O título é obrigatório');
        }
        $this->titulo = $titulo;
    }

    public function setDescricao(string $descricao): void   { $this->descricao  = $descricao; }
    public function setDataLimite(string $data): void       { $this->dataLimite = $data; }
    public function setResponsavelId(int $id): void         { $this->responsavelId = $id; }
    public function setAtualizadoEm(string $dt): void       { $this->atualizadoEm  = $dt; }

    public function setStatus(string $status): void
    {
        $statusValidos = ['pendente', 'em_andamento', 'concluida'];
        if (!in_array($status, $statusValidos)) {
            throw new \InvalidArgumentException('Status inválido');
        }
        $this->status = $status;
    }
}
