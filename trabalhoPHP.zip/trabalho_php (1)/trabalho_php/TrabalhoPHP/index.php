<?php
/*
 * Gerenciador de Tarefas Colaborativo
 * Disciplina: Desenvolvimento de Sistemas - PHP
 * Professor: João Paulo Nunes da Silva
 *
 * Integrantes do Grupo:
 * Enzo F F Chemin      - RGM: 33402621
 * Felipe Paulista Silveira - RGM: 43389988
 * Leonardo Valente Montes  - RGM: 42979846
 * Hygor Daniel Fieszt      - RGM: 41984561
 * Victor Gonçalves         - RGM: 38094649
 */

declare(strict_types=1);

ob_start();

require_once __DIR__ . '/Autoload.php';

use App\Dal\UsuarioDao;
use App\Util\Functions;

session_start();
session_regenerate_id(true);


if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


if (!isset($_SESSION['usuario_id']) && isset($_COOKIE['lembrar_token'])) {
    $tokenCookie   = $_COOKIE['lembrar_token'];
    $usuarioCookie = UsuarioDao::buscarPorToken($tokenCookie);
    if ($usuarioCookie !== null) {
        $_SESSION['usuario_id']    = $usuarioCookie->getId();
        $_SESSION['usuario_nome']  = $usuarioCookie->getNome();
        $_SESSION['usuario_email'] = $usuarioCookie->getEmail();
    } else {
        setcookie('lembrar_token', '', time() - 3600, '/');
    }
}

$page = $_GET['p'] ?? 'home';

// Logout
if ($page === 'sair') {
    if (isset($_COOKIE['lembrar_token']) && isset($_SESSION['usuario_id'])) {
        UsuarioDao::atualizarToken((int) $_SESSION['usuario_id'], null);
        setcookie('lembrar_token', '', time() - 3600, '/');
    }
    session_destroy();
    ob_end_clean();
    header('Location: index.php?p=login');
    exit;
}

$paginasPublicas = ['login', 'cadastro'];


if (!isset($_SESSION['usuario_id']) && !in_array($page, $paginasPublicas)) {
    ob_end_clean();
    header('Location: index.php?p=login');
    exit;
}


if (isset($_SESSION['usuario_id']) && in_array($page, $paginasPublicas)) {
    ob_end_clean();
    header('Location: index.php?p=home');
    exit;
}

$titulo = match($page) {
    'home'          => 'Home',
    'login'         => 'Login',
    'cadastro'      => 'Cadastro',
    'tarefas'       => 'Tarefas',
    'nova-tarefa'   => 'Nova Tarefa',
    'editar-tarefa' => 'Editar Tarefa',
    'detalhe'       => 'Detalhe da Tarefa',
    default         => 'Página não encontrada'
};
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TaskFlow | <?= htmlspecialchars($titulo) ?></title>
    <link rel="stylesheet" href="./assets/style.css">
</head>
<body>

<?php if (isset($_SESSION['usuario_id'])): ?>
<header>
    <div class="header-brand">
        <span class="brand-icon">&#10003;</span>
        <h1>TaskFlow</h1>
    </div>
    <div class="header-usuario">
        <span>Olá, <strong><?= htmlspecialchars($_SESSION['usuario_nome']) ?></strong></span>
    </div>
</header>
<nav>
    <ul>
        <li><a href="?p=home"       <?= $page === 'home'       ? 'class="nav-ativo"' : '' ?>>&#127968; Home</a></li>
        <li><a href="?p=tarefas"    <?= $page === 'tarefas'    ? 'class="nav-ativo"' : '' ?>>&#128203; Tarefas</a></li>
        <li><a href="?p=nova-tarefa"<?= $page === 'nova-tarefa'? 'class="nav-ativo"' : '' ?>>&#43; Nova Tarefa</a></li>
        <li><a href="?p=sair" class="nav-sair">&#128682; Sair</a></li>
    </ul>
</nav>
<?php else: ?>
<header>
    <div class="header-brand">
        <span class="brand-icon">&#10003;</span>
        <h1>TaskFlow</h1>
    </div>
    <div class="header-subtitulo">
        <span>Gerenciador de Tarefas Colaborativo</span>
    </div>
</header>
<?php endif; ?>

<main>
    <section>
    <?php
        require_once match($page) {
            'home'                         => './view/home.php',
            'login'                        => './view/login.php',
            'cadastro'                     => './view/cadastro.php',
            'tarefas'                      => './view/listar.php',
            'nova-tarefa', 'editar-tarefa' => './view/form_tarefa.php',
            'detalhe'                      => './view/detalhe.php',
            default                        => './view/404.php',
        };
    ?>
    </section>
</main>

<footer>
    <p>TaskFlow &copy; <?= date('Y') ?> &mdash; Gerenciador de Tarefas Colaborativo</p>
</footer>

</body>
</html>
<?php ob_end_flush(); ?>
