-- ============================================================
--  TaskFlow — Gerenciador de Tarefas Colaborativo
--  Script de criação do banco de dados MySQL
-- ============================================================

CREATE DATABASE IF NOT EXISTS taskflow
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE taskflow;


CREATE TABLE IF NOT EXISTS usuarios (
    id         INT          AUTO_INCREMENT PRIMARY KEY,
    nome       VARCHAR(100) NOT NULL,
    email      VARCHAR(150) NOT NULL UNIQUE,
    senha      VARCHAR(255) NOT NULL,
    token_lembrar VARCHAR(100) DEFAULT NULL,
    criado_em  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE IF NOT EXISTS tarefas (
    id             INT          AUTO_INCREMENT PRIMARY KEY,
    titulo         VARCHAR(150) NOT NULL,
    descricao      TEXT,
    data_limite    DATE         NOT NULL,
    status         ENUM('pendente','em_andamento','concluida') NOT NULL DEFAULT 'pendente',
    criador_id     INT          NOT NULL,
    responsavel_id INT          NOT NULL,
    criado_em      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (criador_id)     REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (responsavel_id) REFERENCES usuarios(id) ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS comentarios (
    id         INT      AUTO_INCREMENT PRIMARY KEY,
    tarefa_id  INT      NOT NULL,
    usuario_id INT      NOT NULL,
    texto      TEXT     NOT NULL,
    criado_em  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tarefa_id)  REFERENCES tarefas(id)  ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS historico (
    id             INT         AUTO_INCREMENT PRIMARY KEY,
    tarefa_id      INT         NOT NULL,
    usuario_id     INT         NOT NULL,
    acao           VARCHAR(255) NOT NULL,
    criado_em      DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tarefa_id)  REFERENCES tarefas(id)  ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);
