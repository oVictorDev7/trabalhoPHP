<?php

use App\Dal\UsuarioDao;
use App\Model\Usuario;
use App\Util\Functions;

$erro    = null;
$sucesso = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cadastrar'])) {

    $tokenRecebido = $_POST['csrf'] ?? '';

    if (!Functions::validarCsrf($tokenRecebido)) {
        die('Falha de segurança: token CSRF inválido.');
    }

    $nome         = Functions::prepararTexto($_POST['nome'] ?? '');
    $email        = Functions::prepararTexto($_POST['email'] ?? '');
    $senha        = $_POST['senha'] ?? '';
    $senhaConfirm = $_POST['senha_confirm'] ?? '';

    if (empty($nome) || empty($email) || empty($senha) || empty($senhaConfirm)) {
        $erro = 'Preencha todos os campos obrigatórios.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'E-mail inválido.';
    } elseif (strlen($senha) < 6) {
        $erro = 'A senha deve ter pelo menos 6 caracteres.';
    } elseif ($senha !== $senhaConfirm) {
        $erro = 'As senhas não coincidem.';
    } elseif (UsuarioDao::emailExiste($email)) {
        $erro = 'Este e-mail já está cadastrado.';
    } else {
        try {
            $senhaHash = password_hash($senha, PASSWORD_ARGON2ID);
            $usuario   = Usuario::criar(null, $nome, $email, $senhaHash);
            UsuarioDao::cadastrar($usuario);
            $sucesso = 'Cadastro realizado com sucesso! Faça login para continuar.';
        } catch (\Exception $e) {
            $erro = 'Erro ao cadastrar: ' . $e->getMessage();
        }
    }
}
?>
<article class="card-auth">
    <div class="auth-icone">&#43;</div>
    <h2>Criar Conta</h2>

    <?php if ($erro !== null): ?>
        <p class="alerta alerta-erro"><?= htmlspecialchars($erro) ?></p>
    <?php endif; ?>

    <?php if ($sucesso !== null): ?>
        <p class="alerta alerta-sucesso"><?= htmlspecialchars($sucesso) ?></p>
    <?php endif; ?>

    <form action="?p=cadastro" method="post">
        <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">

        <div class="form-grupo">
            <label for="nome">Nome completo: <span class="obrigatorio">*</span></label>
            <input type="text" id="nome" name="nome" required
                   placeholder="Seu nome completo"
                   value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>">
        </div>

        <div class="form-grupo">
            <label for="email">E-mail: <span class="obrigatorio">*</span></label>
            <input type="email" id="email" name="email" required
                   placeholder="seu@email.com"
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        </div>

        <div class="form-grupo">
            <label for="senha">Senha: <span class="obrigatorio">*</span></label>
            <input type="password" id="senha" name="senha" required
                   placeholder="Mínimo 6 caracteres">
        </div>

        <div class="form-grupo">
            <label for="senha_confirm">Confirmar senha: <span class="obrigatorio">*</span></label>
            <input type="password" id="senha_confirm" name="senha_confirm" required
                   placeholder="Repita a senha">
        </div>

        <button type="submit" name="cadastrar" class="btn-primario btn-block">Criar Conta</button>
    </form>

    <p class="auth-link">Já tem conta? <a href="?p=login">Faça login</a></p>
</article>
