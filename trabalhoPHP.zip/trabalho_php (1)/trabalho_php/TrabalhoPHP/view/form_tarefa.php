<?php

use App\Dal\TarefaDao;
use App\Dal\UsuarioDao;
use App\Model\Tarefa;
use App\Util\Functions;

$page      = $_GET['p'] ?? 'nova-tarefa';
$editando  = ($page === 'editar-tarefa');
$tarefaId  = isset($_GET['id']) ? (int) $_GET['id'] : null;
$tarefa    = null;
$erro      = null;
$usuarioId = (int) $_SESSION['usuario_id'];

if ($editando) {
    if ($tarefaId === null) {
        header('Location: index.php?p=tarefas');
        exit;
    }
    $tarefa = TarefaDao::buscarPorId($tarefaId);

    if ($tarefa === null || $tarefa->getCriadorId() !== $usuarioId) {
        header('Location: index.php?p=tarefas');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['salvar_tarefa'])) {

    if (!Functions::validarCsrf($_POST['csrf'] ?? '')) {
        die('Falha de segurança: token CSRF inválido.');
    }

    $titulo        = Functions::prepararTexto($_POST['titulo']        ?? '');
    $descricao     = Functions::prepararTexto($_POST['descricao']     ?? '');
    $dataLimite    = Functions::prepararTexto($_POST['data_limite']   ?? '');
    $responsavelId = (int) ($_POST['responsavel_id'] ?? 0);

    if (empty($titulo)) {
        $erro = 'O título é obrigatório.';
    } elseif (empty($dataLimite)) {
        $erro = 'A data limite é obrigatória.';
    } elseif ($responsavelId === 0) {
        $erro = 'Selecione um responsável.';
    } else {
        try {
            if ($editando && $tarefa !== null) {
                $tarefa->setTitulo($titulo);
                $tarefa->setDescricao($descricao);
                $tarefa->setDataLimite($dataLimite);
                $tarefa->setResponsavelId($responsavelId);

                TarefaDao::atualizar($tarefa);
                TarefaDao::inserirHistorico($tarefaId, $usuarioId, 'Editou: título, descrição, prazo ou responsável');

                header('Location: index.php?p=detalhe&id=' . $tarefa->getId() . '&msg=editada');
                exit;
            } else {
                $novaTarefa = Tarefa::criar(null, $titulo, $descricao, $dataLimite, 'pendente', $usuarioId, $responsavelId);
                $id = TarefaDao::cadastrar($novaTarefa);

                TarefaDao::inserirHistorico($id, $usuarioId, 'Criou a tarefa');

                header('Location: index.php?p=detalhe&id=' . $id . '&msg=criada');
                exit;
            }
        } catch (\Exception $e) {
            $erro = 'Erro ao salvar: ' . $e->getMessage();
        }
    }
}

$usuarios = UsuarioDao::listar();
?>
<section class="pagina-formulario">
    <div class="pagina-cabecalho">
        <h2><?= $editando ? '&#9998; Editar Tarefa' : '&#43; Nova Tarefa' ?></h2>
        <a href="?p=tarefas" class="btn-secundario">&#8592; Voltar</a>
    </div>

    <?php if ($erro !== null): ?>
        <p class="alerta alerta-erro"><?= htmlspecialchars($erro) ?></p>
    <?php endif; ?>

    <form action="?p=<?= $editando ? 'editar-tarefa&id=' . $tarefaId : 'nova-tarefa' ?>"
          method="post" class="form-tarefa">
        <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">

        <div class="form-grupo">
            <label for="titulo">Título: <span class="obrigatorio">*</span></label>
            <input type="text" id="titulo" name="titulo" required maxlength="120"
                   placeholder="Título da tarefa"
                   value="<?= htmlspecialchars($tarefa?->getTitulo() ?? '') ?>">
        </div>

        <div class="form-grupo">
            <label for="descricao">Descrição:</label>
            <textarea id="descricao" name="descricao" rows="5"
                      placeholder="Descreva a tarefa..."><?= htmlspecialchars($tarefa?->getDescricao() ?? '') ?></textarea>
        </div>

        <div class="form-grupo">
            <label for="data_limite">Data Limite: <span class="obrigatorio">*</span></label>
            <input type="date" id="data_limite" name="data_limite" required
                   value="<?= htmlspecialchars($tarefa?->getDataLimite() ?? '') ?>">
        </div>

        <div class="form-grupo">
            <label for="responsavel_id">Responsável: <span class="obrigatorio">*</span></label>
            <select id="responsavel_id" name="responsavel_id" required>
                <option value="">-- Selecione um membro --</option>
                <?php foreach ($usuarios as $usuario): ?>
                    <option value="<?= $usuario->getId() ?>"
                        <?php
                        $selecionado = ($editando && $tarefa !== null)
                            ? $tarefa->getResponsavelId() === $usuario->getId()
                            : $usuario->getId() === $usuarioId;
                        echo $selecionado ? 'selected' : '';
                        ?>>
                        <?= htmlspecialchars($usuario->getNome()) ?>
                        <?= $usuario->getId() === $usuarioId ? ' (você)' : '' ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <?php if ($editando && $tarefa !== null): ?>
        <div class="form-info">
            <p><strong>Status atual:</strong>
                <span class="badge <?= Functions::classeStatus($tarefa->getStatus()) ?>">
                    <?= Functions::labelStatus($tarefa->getStatus()) ?>
                </span>
                &mdash; Para alterar o status, acesse o <a href="?p=detalhe&id=<?= $tarefaId ?>">detalhe da tarefa</a>.
            </p>
        </div>
        <?php endif; ?>

        <div class="form-acoes">
            <button type="submit" name="salvar_tarefa" class="btn-primario">
                <?= $editando ? '&#10003; Salvar Alterações' : '&#43; Criar Tarefa' ?>
            </button>
            <a href="?p=tarefas" class="btn-secundario">Cancelar</a>
        </div>
    </form>
</section>
