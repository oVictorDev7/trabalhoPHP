<?php

use App\Dal\UsuarioDao;
use App\Util\Functions;

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['entrar'])) {

    $tokenRecebido = $_POST['csrf'] ?? '';

    if (!Functions::validarCsrf($tokenRecebido)) {
        die('Falha de segurança: token CSRF inválido.');
    }

    $email   = Functions::prepararTexto($_POST['email'] ?? '');
    $senha   = $_POST['senha'] ?? '';
    $lembrar = isset($_POST['lembrar']);

    if (empty($email) || empty($senha)) {
        $erro = 'Preencha todos os campos.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'E-mail inválido.';
    } else {
        $usuario = UsuarioDao::buscarPorEmail($email);

        if ($usuario !== null && password_verify($senha, $usuario->getSenha())) {
           
            $_SESSION['usuario_id']    = $usuario->getId();
            $_SESSION['usuario_nome']  = $usuario->getNome();
            $_SESSION['usuario_email'] = $usuario->getEmail();

            if ($lembrar) {
                $token = bin2hex(random_bytes(32));
                UsuarioDao::atualizarToken((int) $usuario->getId(), $token);
                setcookie('lembrar_token', $token, time() + (30 * 24 * 3600), '/', '', false, true);
            }

            header('Location: index.php?p=home');
            exit;
        } else {
            $erro = 'E-mail ou senha incorretos.';
        }
    }
}
?>
<article class="card-auth">
    <div class="auth-icone">&#10003;</div>
    <h2>Entrar no TaskFlow</h2>

    <?php if ($erro !== null): ?>
        <p class="alerta alerta-erro"><?= htmlspecialchars($erro) ?></p>
    <?php endif; ?>

    <form action="?p=login" method="post">
        <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">

        <div class="form-grupo">
            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" required
                   placeholder="seu@email.com"
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
        </div>

        <div class="form-grupo">
            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha" required
                   placeholder="Digite sua senha">
        </div>

        <div class="form-grupo form-check">
            <input type="checkbox" id="lembrar" name="lembrar"
                   <?= isset($_POST['lembrar']) ? 'checked' : '' ?>>
            <label for="lembrar">Lembrar de mim por 30 dias</label>
        </div>

        <button type="submit" name="entrar" class="btn-primario btn-block">Entrar</button>
    </form>

    <p class="auth-link">Não tem conta? <a href="?p=cadastro">Cadastre-se aqui</a></p>
</article>
