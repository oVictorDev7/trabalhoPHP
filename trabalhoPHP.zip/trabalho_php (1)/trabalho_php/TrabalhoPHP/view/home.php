<?php

use App\Dal\TarefaDao;
use App\Dal\UsuarioDao;
use App\Util\Functions;

$usuarioId    = (int) $_SESSION['usuario_id'];
$todasTarefas = TarefaDao::listar();
$minhasTarefas = TarefaDao::listar(['responsavel_id' => $usuarioId]);

$totalGlobal    = count($todasTarefas);
$pendentesGlobal  = 0;
$andamentoGlobal  = 0;
$concluidasGlobal = 0;
$hoje = date('Y-m-d');
$atrasadasGlobal  = 0;

foreach ($todasTarefas as $t) {
    switch ($t->getStatus()) {
        case 'pendente':
            $pendentesGlobal++;
            break;
        case 'em_andamento':
            $andamentoGlobal++;
            break;
        case 'concluida':
            $concluidasGlobal++;
            break;
    }
    if ($t->getDataLimite() < $hoje && $t->getStatus() !== 'concluida') {
        $atrasadasGlobal++;
    }
}

$totalMinhas = count($minhasTarefas);
?>
<section class="dashboard">
    <h2>&#127968; Bem-vindo, <?= htmlspecialchars($_SESSION['usuario_nome']) ?>!</h2>
    <p class="dashboard-subtitulo">Aqui está o resumo do sistema.</p>

    <div class="cards-estatisticas">
        <div class="card-stat card-total">
            <span class="stat-numero"><?= $totalGlobal ?></span>
            <span class="stat-label">Total de Tarefas</span>
        </div>
        <div class="card-stat card-pendente">
            <span class="stat-numero"><?= $pendentesGlobal ?></span>
            <span class="stat-label">Pendentes</span>
        </div>
        <div class="card-stat card-andamento">
            <span class="stat-numero"><?= $andamentoGlobal ?></span>
            <span class="stat-label">Em Andamento</span>
        </div>
        <div class="card-stat card-concluida">
            <span class="stat-numero"><?= $concluidasGlobal ?></span>
            <span class="stat-label">Concluídas</span>
        </div>
        <?php if ($atrasadasGlobal > 0): ?>
        <div class="card-stat card-atrasada">
            <span class="stat-numero"><?= $atrasadasGlobal ?></span>
            <span class="stat-label">Atrasadas &#9888;</span>
        </div>
        <?php endif; ?>
    </div>

    <div class="dashboard-secao">
        <div class="secao-cabecalho">
            <h3>&#128203; Minhas Tarefas (<?= $totalMinhas ?>)</h3>
            <a href="?p=tarefas&responsavel=<?= $usuarioId ?>" class="btn-secundario">Ver todas</a>
        </div>

        <?php if (empty($minhasTarefas)): ?>
            <p class="sem-dados">Você não tem tarefas atribuídas.
                <a href="?p=nova-tarefa">Criar nova tarefa</a>
            </p>
        <?php else: ?>
            <table class="tabela-tarefas">
                <thead>
                    <tr>
                        <th>Título</th>
                        <th>Status</th>
                        <th>Prazo</th>
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                
                $contador = 0;
                foreach ($minhasTarefas as $tarefa):
                    if ($contador >= 5) break;
                    $atrasada = $tarefa->getDataLimite() < $hoje && $tarefa->getStatus() !== 'concluida';
                    $contador++;
                ?>
                    <tr class="<?= $atrasada ? 'linha-atrasada' : '' ?>">
                        <td><?= htmlspecialchars($tarefa->getTitulo()) ?></td>
                        <td>
                            <span class="badge <?= Functions::classeStatus($tarefa->getStatus()) ?>">
                                <?= Functions::iconeStatus($tarefa->getStatus()) ?>
                                <?= Functions::labelStatus($tarefa->getStatus()) ?>
                            </span>
                        </td>
                        <td class="<?= $atrasada ? 'data-atrasada' : '' ?>">
                            <?= Functions::formatarData($tarefa->getDataLimite()) ?>
                            <?= $atrasada ? '<span class="icone-alerta">&#9888;</span>' : '' ?>
                        </td>
                        <td>
                            <a href="?p=detalhe&id=<?= $tarefa->getId() ?>" class="btn-link">Ver</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- Atalhos rápidos -->
    <div class="dashboard-atalhos">
        <a href="?p=nova-tarefa" class="atalho-card">
            <span class="atalho-icone">&#43;</span>
            <span>Nova Tarefa</span>
        </a>
        <a href="?p=tarefas" class="atalho-card">
            <span class="atalho-icone">&#128203;</span>
            <span>Ver Tarefas</span>
        </a>
        <a href="?p=tarefas&status=pendente" class="atalho-card">
            <span class="atalho-icone">&#9200;</span>
            <span>Pendentes</span>
        </a>
        <a href="?p=tarefas&status=em_andamento" class="atalho-card">
            <span class="atalho-icone">&#9654;</span>
            <span>Em Andamento</span>
        </a>
    </div>
</section>
