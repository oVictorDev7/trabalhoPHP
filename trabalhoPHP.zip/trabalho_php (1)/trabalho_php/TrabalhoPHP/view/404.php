<article class="card-404">
    <span class="icone-404">&#128533;</span>
    <h2>404 — Página não encontrada</h2>
    <p>A página que você está tentando acessar não existe.</p>
    <a href="index.php?p=home" class="btn-primario">&#127968; Voltar para o início</a>
</article>
