<?php

use App\Dal\TarefaDao;
use App\Dal\UsuarioDao;
use App\Util\Functions;


$msg = $_GET['msg'] ?? '';


$filtroResponsavel = $_GET['responsavel'] ?? '';
$filtroStatus      = $_GET['status']      ?? '';
$filtroData        = $_GET['data_limite'] ?? '';

$filtros = [];
if (!empty($filtroResponsavel)) $filtros['responsavel_id'] = (int) $filtroResponsavel;
if (!empty($filtroStatus))      $filtros['status']         = $filtroStatus;
if (!empty($filtroData))        $filtros['data_limite']    = $filtroData;

$tarefas  = TarefaDao::listar($filtros);
$usuarios = UsuarioDao::listar();
$hoje     = date('Y-m-d');
?>
<section class="pagina-tarefas">
    <div class="pagina-cabecalho">
        <h2>&#128203; Tarefas</h2>
        <a href="?p=nova-tarefa" class="btn-primario">&#43; Nova Tarefa</a>
    </div>

    <?php if ($msg === 'deletada'): ?>
        <p class="alerta alerta-sucesso">&#10003; Tarefa deletada com sucesso!</p>
    <?php endif; ?>

    <form action="index.php" method="get" class="form-filtros">
        <input type="hidden" name="p" value="tarefas">

        <div class="filtro-grupo">
            <label for="filtro-responsavel">Responsável:</label>
            <select id="filtro-responsavel" name="responsavel">
                <option value="">Todos</option>
                <?php foreach ($usuarios as $usuario): ?>
                    <option value="<?= $usuario->getId() ?>"
                        <?= $filtroResponsavel == $usuario->getId() ? 'selected' : '' ?>>
                        <?= htmlspecialchars($usuario->getNome()) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="filtro-grupo">
            <label for="filtro-status">Status:</label>
            <select id="filtro-status" name="status">
                <option value="">Todos</option>
                <option value="pendente"     <?= $filtroStatus === 'pendente'     ? 'selected' : '' ?>>Pendente</option>
                <option value="em_andamento" <?= $filtroStatus === 'em_andamento' ? 'selected' : '' ?>>Em Andamento</option>
                <option value="concluida"    <?= $filtroStatus === 'concluida'    ? 'selected' : '' ?>>Concluída</option>
            </select>
        </div>

        <div class="filtro-grupo">
            <label for="filtro-data">Data Limite:</label>
            <input type="date" id="filtro-data" name="data_limite"
                   value="<?= htmlspecialchars($filtroData) ?>">
        </div>

        <div class="filtro-botoes">
            <button type="submit" class="btn-filtrar">&#128269; Filtrar</button>
            <a href="?p=tarefas" class="btn-limpar">&#10005; Limpar</a>
        </div>
    </form>

    <?php if (!empty($filtros)): ?>
        <p class="filtro-info">
            Exibindo <strong><?= count($tarefas) ?></strong> tarefa(s) com filtros ativos.
        </p>
    <?php endif; ?>

    <?php if (empty($tarefas)): ?>
        <p class="sem-dados">Nenhuma tarefa encontrada.
            <a href="?p=nova-tarefa">Criar a primeira tarefa?</a>
        </p>
    <?php else: ?>
        <table class="tabela-tarefas">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Título</th>
                    <th>Responsável</th>
                    <th>Criador</th>
                    <th>Status</th>
                    <th>Prazo</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($tarefas as $tarefa):
                $responsavel = UsuarioDao::buscarPorId($tarefa->getResponsavelId());
                $criador     = UsuarioDao::buscarPorId($tarefa->getCriadorId());
                $atrasada    = $tarefa->getDataLimite() < $hoje && $tarefa->getStatus() !== 'concluida';
                $usuarioId   = (int) $_SESSION['usuario_id'];
            ?>
                <tr class="<?= $atrasada ? 'linha-atrasada' : '' ?>">
                    <td><?= $tarefa->getId() ?></td>
                    <td class="col-titulo"><?= htmlspecialchars($tarefa->getTitulo()) ?></td>
                    <td><?= htmlspecialchars($responsavel?->getNome() ?? '—') ?></td>
                    <td><?= htmlspecialchars($criador?->getNome() ?? '—') ?></td>
                    <td>
                        <span class="badge <?= Functions::classeStatus($tarefa->getStatus()) ?>">
                            <?= Functions::iconeStatus($tarefa->getStatus()) ?>
                            <?= Functions::labelStatus($tarefa->getStatus()) ?>
                        </span>
                    </td>
                    <td class="<?= $atrasada ? 'data-atrasada' : '' ?>">
                        <?= Functions::formatarData($tarefa->getDataLimite()) ?>
                        <?= $atrasada ? '<span class="icone-alerta" title="Atrasada">&#9888;</span>' : '' ?>
                    </td>
                    <td class="col-acoes">
                        <a href="?p=detalhe&id=<?= $tarefa->getId() ?>" class="btn-link">&#128065; Ver</a>
                        <?php if ($tarefa->getCriadorId() === $usuarioId): ?>
                            <a href="?p=editar-tarefa&id=<?= $tarefa->getId() ?>" class="btn-link btn-editar">&#9998; Editar</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>
