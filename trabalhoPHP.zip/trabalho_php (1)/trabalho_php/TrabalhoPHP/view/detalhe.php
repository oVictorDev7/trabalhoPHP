<?php

use App\Dal\TarefaDao;
use App\Dal\UsuarioDao;
use App\Util\Functions;

$usuarioId = (int) $_SESSION['usuario_id'];
$tarefaId  = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$tarefa    = TarefaDao::buscarPorId($tarefaId);

if ($tarefa === null) {
    header('Location: index.php?p=tarefas');
    exit;
}

$ehCriador     = ($tarefa->getCriadorId()     === $usuarioId);
$ehResponsavel = ($tarefa->getResponsavelId() === $usuarioId);
$podeAlterar   = $ehCriador || $ehResponsavel;

$erro    = null;
$sucesso = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar_status'])) {

    if (!Functions::validarCsrf($_POST['csrf'] ?? '')) {
        die('Token CSRF inválido.');
    }

    if (!$podeAlterar) {
        $erro = 'Você não tem permissão para alterar o status desta tarefa.';
    } else {
        $novoStatus = Functions::prepararTexto($_POST['status'] ?? '');
        try {
            $statusAntigo = Functions::labelStatus($tarefa->getStatus());
            $tarefa->setStatus($novoStatus);
            TarefaDao::atualizar($tarefa);

            // Registra no histórico do banco
            $acao = 'Alterou status: "' . $statusAntigo . '" → "' . Functions::labelStatus($novoStatus) . '"';
            TarefaDao::inserirHistorico($tarefaId, $usuarioId, $acao);

            $sucesso = 'Status atualizado com sucesso!';
            $tarefa  = TarefaDao::buscarPorId($tarefaId);
        } catch (\Exception $e) {
            $erro = 'Erro: ' . $e->getMessage();
        }
    }
}

// ---------------------------------------------------------------
// POST: Adicionar Comentário
// ---------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comentar'])) {

    if (!Functions::validarCsrf($_POST['csrf'] ?? '')) {
        die('Token CSRF inválido.');
    }

    $texto = Functions::prepararTexto($_POST['comentario'] ?? '');

    if (empty($texto)) {
        $erro = 'O comentário não pode estar vazio.';
    } else {
        // Insere comentário e histórico diretamente no banco
        TarefaDao::inserirComentario($tarefaId, $usuarioId, $texto);
        TarefaDao::inserirHistorico($tarefaId, $usuarioId, 'Adicionou um comentário');

        $sucesso = 'Comentário adicionado!';
        $tarefa  = TarefaDao::buscarPorId($tarefaId);
    }
}

// ---------------------------------------------------------------
// POST: Deletar Tarefa (somente criador)
// ---------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deletar_tarefa'])) {

    if (!Functions::validarCsrf($_POST['csrf'] ?? '')) {
        die('Token CSRF inválido.');
    }

    if (!$ehCriador) {
        $erro = 'Somente o criador pode deletar esta tarefa.';
    } else {
        TarefaDao::deletar($tarefaId);
        header('Location: index.php?p=tarefas&msg=deletada');
        exit;
    }
}

$criador     = UsuarioDao::buscarPorId($tarefa->getCriadorId());
$responsavel = UsuarioDao::buscarPorId($tarefa->getResponsavelId());
$hoje        = date('Y-m-d');
$atrasada    = $tarefa->getDataLimite() < $hoje && $tarefa->getStatus() !== 'concluida';

$msgGet = $_GET['msg'] ?? '';
?>
<section class="pagina-detalhe">

    <div class="pagina-cabecalho">
        <h2>&#128203; Detalhe da Tarefa #<?= $tarefa->getId() ?></h2>
        <div class="cabecalho-acoes">
            <a href="?p=tarefas" class="btn-secundario">&#8592; Voltar</a>
            <?php if ($ehCriador): ?>
                <a href="?p=editar-tarefa&id=<?= $tarefa->getId() ?>" class="btn-primario">&#9998; Editar</a>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msgGet === 'criada'): ?>
        <p class="alerta alerta-sucesso">&#10003; Tarefa criada com sucesso!</p>
    <?php elseif ($msgGet === 'editada'): ?>
        <p class="alerta alerta-sucesso">&#10003; Tarefa editada com sucesso!</p>
    <?php endif; ?>
    <?php if ($sucesso !== null): ?>
        <p class="alerta alerta-sucesso"><?= htmlspecialchars($sucesso) ?></p>
    <?php endif; ?>
    <?php if ($erro !== null): ?>
        <p class="alerta alerta-erro"><?= htmlspecialchars($erro) ?></p>
    <?php endif; ?>

    <!-- Informações da tarefa -->
    <article class="card-detalhe">
        <div class="detalhe-titulo">
            <h3><?= htmlspecialchars($tarefa->getTitulo()) ?></h3>
            <span class="badge <?= Functions::classeStatus($tarefa->getStatus()) ?>">
                <?= Functions::iconeStatus($tarefa->getStatus()) ?>
                <?= Functions::labelStatus($tarefa->getStatus()) ?>
            </span>
        </div>

        <?php if (!empty($tarefa->getDescricao())): ?>
        <div class="detalhe-descricao">
            <p><?= nl2br(htmlspecialchars($tarefa->getDescricao())) ?></p>
        </div>
        <?php endif; ?>

        <div class="detalhe-meta">
            <div class="meta-item">
                <span class="meta-label">&#128100; Criador:</span>
                <span><?= htmlspecialchars($criador?->getNome() ?? '—') ?></span>
            </div>
            <div class="meta-item">
                <span class="meta-label">&#127919; Responsável:</span>
                <span><?= htmlspecialchars($responsavel?->getNome() ?? '—') ?></span>
            </div>
            <div class="meta-item">
                <span class="meta-label">&#128197; Prazo:</span>
                <span class="<?= $atrasada ? 'data-atrasada' : '' ?>">
                    <?= Functions::formatarData($tarefa->getDataLimite()) ?>
                    <?= $atrasada ? '<span class="icone-alerta">&#9888; Atrasada</span>' : '' ?>
                </span>
            </div>
            <div class="meta-item">
                <span class="meta-label">&#128336; Criado em:</span>
                <span><?= date('d/m/Y H:i', strtotime($tarefa->getCriadoEm())) ?></span>
            </div>
        </div>
    </article>

    <!-- Atualizar Status -->
    <?php if ($podeAlterar): ?>
    <article class="card-acao">
        <h4>&#128260; Atualizar Status</h4>
        <form action="?p=detalhe&id=<?= $tarefa->getId() ?>" method="post" class="form-status">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
            <select name="status">
                <option value="pendente"     <?= $tarefa->getStatus() === 'pendente'     ? 'selected' : '' ?>>&#9200; Pendente</option>
                <option value="em_andamento" <?= $tarefa->getStatus() === 'em_andamento' ? 'selected' : '' ?>>&#9654; Em Andamento</option>
                <option value="concluida"    <?= $tarefa->getStatus() === 'concluida'    ? 'selected' : '' ?>>&#10003; Concluída</option>
            </select>
            <button type="submit" name="atualizar_status" class="btn-primario">Atualizar</button>
        </form>
    </article>
    <?php endif; ?>

    <!-- Comentários -->
    <article class="card-comentarios">
        <h4>&#128172; Comentários (<?= count($tarefa->getComentarios()) ?>)</h4>

        <div class="lista-comentarios">
        <?php
        $comentarios = $tarefa->getComentarios();
        if (empty($comentarios)):
        ?>
            <p class="sem-dados">Nenhum comentário ainda. Seja o primeiro!</p>
        <?php else: ?>
            <?php foreach ($comentarios as $comentario):
                $autorCom = UsuarioDao::buscarPorId((int) $comentario['usuario_id']);
                $souEu    = ((int) $comentario['usuario_id'] === $usuarioId);
            ?>
            <div class="comentario <?= $souEu ? 'comentario-meu' : '' ?>">
                <div class="comentario-cabecalho">
                    <span class="comentario-autor">
                        <?= $souEu ? '&#128100; Você' : htmlspecialchars($autorCom?->getNome() ?? '—') ?>
                    </span>
                    <span class="comentario-data">
                        <?= date('d/m/Y H:i', strtotime($comentario['criado_em'])) ?>
                    </span>
                </div>
                <p class="comentario-texto"><?= nl2br(htmlspecialchars($comentario['texto'])) ?></p>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
        </div>

        <form action="?p=detalhe&id=<?= $tarefa->getId() ?>" method="post" class="form-comentario">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
            <textarea name="comentario" rows="3"
                      placeholder="Escreva um comentário sobre esta tarefa..."></textarea>
            <button type="submit" name="comentar" class="btn-primario">&#128172; Comentar</button>
        </form>
    </article>

    <!-- Histórico -->
    <article class="card-historico">
        <h4>&#128220; Histórico de Alterações</h4>
        <?php
        $historico = $tarefa->getHistorico();
        if (empty($historico)):
        ?>
            <p class="sem-dados">Nenhuma alteração registrada.</p>
        <?php else: ?>
            <ol class="lista-historico">
            <?php foreach ($historico as $entrada):
                $autorHist = UsuarioDao::buscarPorId((int) $entrada['usuario_id']);
            ?>
                <li class="historico-item">
                    <span class="historico-icone">&#128336;</span>
                    <div class="historico-info">
                        <span class="historico-acao"><?= htmlspecialchars($entrada['acao']) ?></span>
                        <span class="historico-meta">
                            por <strong><?= htmlspecialchars($autorHist?->getNome() ?? '—') ?></strong>
                            em <?= date('d/m/Y \à\s H:i', strtotime($entrada['criado_em'])) ?>
                        </span>
                    </div>
                </li>
            <?php endforeach; ?>
            </ol>
        <?php endif; ?>
    </article>

    <!-- Deletar tarefa -->
    <?php if ($ehCriador): ?>
    <article class="card-deletar">
        <h4>&#128465; Zona de Perigo</h4>
        <p>Esta ação é irreversível. Todos os comentários e histórico serão perdidos.</p>
        <form action="?p=detalhe&id=<?= $tarefa->getId() ?>" method="post"
              onsubmit="return confirm('Tem certeza que deseja deletar esta tarefa?')">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_token'] ?? '') ?>">
            <button type="submit" name="deletar_tarefa" class="btn-deletar">&#128465; Deletar Tarefa</button>
        </form>
    </article>
    <?php endif; ?>

</section>
